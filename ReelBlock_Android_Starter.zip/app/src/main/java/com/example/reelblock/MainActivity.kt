package com.example.reelblock

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.os.Bundle

private val Bg = Color(0xFF090A12)
private val Card = Color(0xFF171927)
private val Purple = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF56D9E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReelBlockScreen(this) }
    }
}

@Composable
private fun ReelBlockScreen(activity: ComponentActivity) {
    val prefs = activity.getSharedPreferences("reelblock", Context.MODE_PRIVATE)
    var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", true)) }
    var blockedCount by remember { mutableIntStateOf(prefs.getInt("blocked_count", 0)) }
    val serviceEnabled = remember { mutableStateOf(isAccessibilityEnabled(activity)) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Purple,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF17132B), Bg, Bg))
            ).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Spacer(Modifier.height(14.dp))
            Text("REELBLOCK", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("Take back your scroll.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
            Text("Block Reels. Keep the rest of Instagram.", color = Color.LightGray, fontSize = 14.sp)

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("Reels blocking", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(if (enabled) "Protection is switched on" else "Protection is paused", color = Color.LightGray, fontSize = 12.sp)
                        }
                        Switch(checked = enabled, onCheckedChange = {
                            enabled = it
                            prefs.edit().putBoolean("enabled", it).apply()
                        })
                    }
                    HorizontalDivider(color = Color(0xFF34364A))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Reels blocked", color = Color.LightGray)
                        Text(blockedCount.toString(), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    }
                    Text("Counter updates when a likely Reel screen is detected.", color = Color.Gray, fontSize = 11.sp)
                }
            }

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Setup", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).background(if (serviceEnabled.value) Cyan else Color(0xFFFFB45C), RoundedCornerShape(50)))
                        Spacer(Modifier.width(9.dp))
                        Text(if (serviceEnabled.value) "Accessibility service enabled" else "Accessibility service needs enabling", fontSize = 13.sp)
                    }
                    Button(
                        onClick = { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) { Text("Open Accessibility Settings", color = Color.White) }
                    OutlinedButton(
                        onClick = { serviceEnabled.value = isAccessibilityEnabled(activity) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Refresh status") }
                }
            }

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("What stays available", fontWeight = FontWeight.Bold)
                    Text("DMs • Feed • Stories • Profiles • Search", color = Color.LightGray, fontSize = 13.sp)
                    Text("Detection is heuristic. Instagram updates can change its interface, so some Reels may not be detected and occasional false blocks are possible.", color = Color.Gray, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("Private by design • No Instagram login • No data upload", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

private fun isAccessibilityEnabled(context: Context): Boolean {
    val expected = ComponentName(context, ReelsAccessibilityService::class.java)
    val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    val splitter = TextUtils.SimpleStringSplitter(':')
    splitter.setString(enabled)
    while (splitter.hasNext()) {
        if (splitter.next().equals(expected.flattenToString(), ignoreCase = true)) return true
    }
    return false
}
