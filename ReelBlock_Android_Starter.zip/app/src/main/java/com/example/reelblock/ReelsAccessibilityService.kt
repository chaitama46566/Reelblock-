package com.example.reelblock

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.content.Context
import android.content.SharedPreferences

/**
 * Best-effort local detector. Instagram's UI is not a stable public API.
 * It uses conservative combinations of visible accessibility labels and
 * blocks by navigating back rather than drawing over or altering Instagram.
 */
class ReelsAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L
    private lateinit var prefs: SharedPreferences

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("reelblock", Context.MODE_PRIVATE)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::prefs.isInitialized) return
        if (!prefs.getBoolean("enabled", true)) return
        if (event.packageName?.toString() != "com.instagram.android") return

        val root = rootInActiveWindow ?: return
        val labels = mutableListOf<String>()
        collectText(root, labels)
        val text = labels.joinToString(" ").lowercase()

        // Conservative signal set: require Reel-specific language plus
        // multiple Reel interaction controls to reduce accidental feed blocks.
        val reelSpecific = listOf("reels", "original audio", "use audio", "remix").count { text.contains(it) }
        val interactions = listOf("like", "comment", "share").count { text.contains(it) }

        if (reelSpecific >= 2 && interactions >= 2) {
            val now = System.currentTimeMillis()
            if (now - lastBlockedAt > 1800) {
                lastBlockedAt = now
                prefs.edit().putInt("blocked_count", prefs.getInt("blocked_count", 0) + 1).apply()
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
        root.recycle()
    }

    private fun collectText(node: android.view.accessibility.AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.let { if (it.isNotBlank()) out.add(it) }
        node.contentDescription?.toString()?.let { if (it.isNotBlank()) out.add(it) }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectText(child, out)
            child.recycle()
        }
    }

    override fun onInterrupt() = Unit
}
